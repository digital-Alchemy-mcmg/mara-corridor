from __future__ import annotations

from spatial_dna.contracts import (
    ApplicationRouting,
    B1Decomposition,
    B1RequirementAtom,
    CandidateEvidenceAtom,
    EvidenceCandidate,
    GateAuditResult,
    GateDisposition,
    MalformState,
    ResolutionState,
    ScoutObservationPacket,
    SDNAPlaneId,
    SemanticClass,
    SourceSpan,
    TargetIdentification,
)
from spatial_dna.orchestrator import MaraBToB5BoundaryOrchestrator


class FixtureDecomposer:
    def decompose(self, packet, diagnostic_mode):
        spans = [SourceSpan("S-01", packet.raw_posting)]
        return B1Decomposition(
            target_id="target-fixture",
            identification=TargetIdentification(organization="ORG", job_title="ROLE"),
            routing=ApplicationRouting(
                origin="ORG",
                destination="DEST",
                malform_state=MalformState.VALID,
                diagnostic_authorized=diagnostic_mode,
            ),
            source_spans=spans,
            requirements=[
                B1RequirementAtom(
                    requirement_id="r1",
                    text="Must hold credential X",
                    semantic_class=SemanticClass.HARD_GATE,
                    source_span_ids=["S-01"],
                    branch_path=["admission", "credential"],
                ),
                B1RequirementAtom(
                    requirement_id="r2",
                    text="Lead operating team",
                    semantic_class=SemanticClass.ROLE_RESPONSIBILITY,
                    source_span_ids=["S-01"],
                    branch_path=["operations", "leadership"],
                ),
            ],
        )


class FixtureRouter:
    def eligible_planes(self, node):
        if node.semantic_class == SemanticClass.HARD_GATE:
            return [SDNAPlaneId.PLANE_03_EDUCATION_TECH]
        return [SDNAPlaneId.PLANE_02_WORK_HISTORY]


class FixtureSelector:
    def select(self, node, satisfaction_question, eligible_atoms):
        # Crucial invariant: selection is a subset, not wholesale plane attachment.
        if not eligible_atoms:
            return []
        return [EvidenceCandidate(eligible_atoms[0], 0.9, "responsive fixture atom")]


class FixturePropositionBuilder:
    def build(self, node, satisfaction_question, selected):
        if not selected:
            return (f"No selected evidence establishes {node.text}", "No responsive atom selected")
        return (f"Selected evidence may support {node.text}", "One responsive atom selected")


class FixtureAuditor:
    def audit(self, binding):
        if binding.semantic_class == SemanticClass.HARD_GATE:
            return GateAuditResult(
                disposition=GateDisposition.RETURN_CONDITIONAL,
                resolution_state=ResolutionState.UNRESOLVED_ATOMIC_LEVEL,
                final_proposition="Credential X remains unresolved.",
                defect_reason="Selected evidence does not specifically establish the mandatory credential.",
                bound_atom_ids=[],
                excluded_atom_ids=[a.atom_id for a in binding.selected_atoms],
            )
        return GateAuditResult(
            disposition=GateDisposition.PASS,
            resolution_state=ResolutionState.FULLY_SUPPORTED,
            final_proposition="Operating-team leadership is specifically established.",
            bound_atom_ids=[a.atom_id for a in binding.selected_atoms],
            excluded_atom_ids=[],
        )


def build_pipeline():
    return MaraBToB5BoundaryOrchestrator(
        decomposer=FixtureDecomposer(),
        plane_router=FixtureRouter(),
        evidence_selector=FixtureSelector(),
        proposition_builder=FixturePropositionBuilder(),
        truth_auditor=FixtureAuditor(),
    )


def test_stops_at_b5_entry_and_preserves_gate_states():
    pipeline = build_pipeline()
    packet = ScoutObservationPacket(packet_id="pkt-1", raw_posting="fixture source text")
    vault = {
        SDNAPlaneId.PLANE_03_EDUCATION_TECH: [
            CandidateEvidenceAtom("edu-1", SDNAPlaneId.PLANE_03_EDUCATION_TECH, "doc", "Related training, no credential X")
        ],
        SDNAPlaneId.PLANE_02_WORK_HISTORY: [
            CandidateEvidenceAtom("work-1", SDNAPlaneId.PLANE_02_WORK_HISTORY, "doc", "Led operating team")
        ],
    }
    result = pipeline.run(packet, vault)

    assert result.status == "READY_FOR_B5_SEMANTIC_CORE"
    assert len(result.unresolved_nodes) == 1
    assert len(result.fully_supported_nodes) == 1
    assert not result.qualified_nodes
    assert not result.contradicted_nodes


def test_b3_does_not_bind_entire_plane():
    pipeline = build_pipeline()
    packet = ScoutObservationPacket(packet_id="pkt-2", raw_posting="fixture source text")
    vault = {
        SDNAPlaneId.PLANE_03_EDUCATION_TECH: [
            CandidateEvidenceAtom("edu-1", SDNAPlaneId.PLANE_03_EDUCATION_TECH, "doc", "A"),
            CandidateEvidenceAtom("edu-2", SDNAPlaneId.PLANE_03_EDUCATION_TECH, "doc", "B"),
        ],
        SDNAPlaneId.PLANE_02_WORK_HISTORY: [
            CandidateEvidenceAtom("work-1", SDNAPlaneId.PLANE_02_WORK_HISTORY, "doc", "C"),
            CandidateEvidenceAtom("work-2", SDNAPlaneId.PLANE_02_WORK_HISTORY, "doc", "D"),
        ],
    }
    result = pipeline.run(packet, vault)

    for record in result.audited_records.values():
        assert len(record.bound_atoms) <= 1


def test_hard_gate_cannot_be_qualified_into_satisfaction():
    class BadAuditor(FixtureAuditor):
        def audit(self, binding):
            if binding.semantic_class == SemanticClass.HARD_GATE:
                return GateAuditResult(
                    disposition=GateDisposition.RETURN_CONDITIONAL,
                    resolution_state=ResolutionState.QUALIFIED_RESTRICTED_SCOPE,
                    final_proposition="Improperly narrowed hard gate",
                    defect_reason="fixture",
                    bound_atom_ids=[],
                    excluded_atom_ids=[a.atom_id for a in binding.selected_atoms],
                )
            return super().audit(binding)

    pipeline = MaraBToB5BoundaryOrchestrator(
        decomposer=FixtureDecomposer(),
        plane_router=FixtureRouter(),
        evidence_selector=FixtureSelector(),
        proposition_builder=FixturePropositionBuilder(),
        truth_auditor=BadAuditor(),
    )
    packet = ScoutObservationPacket(packet_id="pkt-3", raw_posting="fixture source text")
    vault = {
        SDNAPlaneId.PLANE_03_EDUCATION_TECH: [CandidateEvidenceAtom("edu-1", SDNAPlaneId.PLANE_03_EDUCATION_TECH, "doc", "A")],
        SDNAPlaneId.PLANE_02_WORK_HISTORY: [CandidateEvidenceAtom("work-1", SDNAPlaneId.PLANE_02_WORK_HISTORY, "doc", "B")],
    }

    try:
        pipeline.run(packet, vault)
    except ValueError as exc:
        assert "Hard-gate violation" in str(exc)
    else:
        raise AssertionError("Expected B4 hard-gate invariant to reject qualified satisfaction")
