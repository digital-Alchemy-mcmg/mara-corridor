from __future__ import annotations

from collections import defaultdict
from typing import Dict, Iterable, List

from .contracts import (
    ApplicationRouting,
    B1Decomposition,
    B2TargetNode,
    B2TargetTree,
    B3SubmittedBinding,
    B4AuditedRecord,
    B5EntryPacket,
    CandidateEvidenceAtom,
    GateDisposition,
    MalformState,
    ResolutionState,
    ScoutObservationPacket,
    SDNAPlaneId,
    SemanticClass,
)
from .interfaces import EvidenceSelector, PlaneRouter, PropositionBuilder, TargetDecomposer, TruthAuditor


class StageB_Handoff:
    """Scout→MARA schema boundary.

    It validates shape only. It does not interpret the target or inspect candidate data.
    """

    def execute(self, packet: ScoutObservationPacket) -> ScoutObservationPacket:
        if not packet.packet_id.strip():
            raise ValueError("B handoff rejected: packet_id is required.")
        if not packet.raw_posting.strip():
            raise ValueError("B handoff rejected: raw_posting is required.")
        return packet


class StageB1_Decouple:
    """Candidate-blind target decomposition.

    Semantic extraction is delegated so runtime code contains no target-specific mock data.
    """

    def __init__(self, decomposer: TargetDecomposer):
        self.decomposer = decomposer

    def execute(self, packet: ScoutObservationPacket, diagnostic_mode: bool = True) -> B1Decomposition:
        result = self.decomposer.decompose(packet, diagnostic_mode=diagnostic_mode)
        self._validate_malform(result.routing, diagnostic_mode)
        self._validate_candidate_blind_result(result)
        return result

    @staticmethod
    def _validate_malform(routing: ApplicationRouting, diagnostic_mode: bool) -> None:
        if routing.malform_state != MalformState.VALID and not diagnostic_mode:
            raise ValueError(f"Target object halted in B1: {routing.malform_state.value}")

    @staticmethod
    def _validate_candidate_blind_result(result: B1Decomposition) -> None:
        if not result.target_id:
            raise ValueError("B1 decomposition must produce target_id.")
        span_ids = {s.span_id for s in result.source_spans}
        for req in result.requirements:
            missing = set(req.source_span_ids) - span_ids
            if missing:
                raise ValueError(
                    f"B1 requirement {req.requirement_id} references missing source spans: {sorted(missing)}"
                )


class StageB2_CreateTree:
    """Deterministic target tree construction from B1 atoms.

    Addresses use lowercase letters and numbers only. Branches are target-derived; B2 does
    not impose a fixed semantic taxonomy.
    """

    def execute(self, decomposition: B1Decomposition) -> B2TargetTree:
        tree = B2TargetTree(
            target_id=decomposition.target_id,
            identification=decomposition.identification,
            routing=decomposition.routing,
        )

        if not decomposition.requirements:
            tree.freeze()
            return tree

        paths = [tuple(self._normalize_label(x) for x in req.branch_path) for req in decomposition.requirements]
        if any(not p for p in paths):
            raise ValueError("B2 cannot address a requirement with an empty branch_path.")

        # Root labels receive stable lowercase letters.
        roots = sorted({p[0] for p in paths})
        if len(roots) > 26:
            raise ValueError("B2 reference allocator currently supports at most 26 root branches.")
        root_letters = {root: chr(ord("a") + idx) for idx, root in enumerate(roots)}

        # Every deeper branch label receives a stable numeric sibling ordinal under its parent.
        children: Dict[tuple[str, ...], List[str]] = defaultdict(list)
        for path in sorted(set(paths)):
            for depth in range(1, len(path)):
                parent = path[:depth]
                child = path[depth]
                if child not in children[parent]:
                    children[parent].append(child)
        for parent in children:
            children[parent] = sorted(children[parent])

        leaf_counters: Dict[tuple[str, ...], int] = defaultdict(int)
        reqs = sorted(
            zip(decomposition.requirements, paths),
            key=lambda pair: (pair[1], pair[0].requirement_id),
        )

        for req, path in reqs:
            components = [root_letters[path[0]]]
            for depth in range(1, len(path)):
                parent = path[:depth]
                child = path[depth]
                components.append(str(children[parent].index(child) + 1))

            leaf_counters[path] += 1
            components.append(str(leaf_counters[path]))
            address = ".".join(components)
            parent_address = ".".join(components[:-1]) or None

            tree.add_node(
                B2TargetNode(
                    address=address,
                    text=req.text,
                    semantic_class=req.semantic_class,
                    source_span_ids=list(req.source_span_ids),
                    qualifiers=list(req.qualifiers),
                    parent_address=parent_address,
                    branch_path=list(req.branch_path),
                )
            )

        tree.freeze()
        return tree

    @staticmethod
    def _normalize_label(label: str) -> str:
        norm = " ".join(label.strip().lower().split())
        if not norm:
            raise ValueError("B2 branch labels cannot be blank.")
        return norm


class StageB3_Bind:
    """Target-node-driven candidate evidence discovery and binding."""

    def __init__(
        self,
        plane_router: PlaneRouter,
        evidence_selector: EvidenceSelector,
        proposition_builder: PropositionBuilder,
    ):
        self.plane_router = plane_router
        self.evidence_selector = evidence_selector
        self.proposition_builder = proposition_builder

    def execute(
        self,
        tree: B2TargetTree,
        candidate_vault: Dict[SDNAPlaneId, List[CandidateEvidenceAtom]],
    ) -> List[B3SubmittedBinding]:
        if not tree.frozen:
            raise ValueError("B3 requires a frozen B2 target tree.")

        submitted: List[B3SubmittedBinding] = []
        for address in sorted(tree.nodes):
            node = tree.nodes[address]
            question = self._derive_question(node)
            eligible_planes = self.plane_router.eligible_planes(node)

            eligible_atoms: List[CandidateEvidenceAtom] = []
            for plane in eligible_planes:
                eligible_atoms.extend(candidate_vault.get(plane, []))

            selected = self.evidence_selector.select(node, question, eligible_atoms)
            selected = sorted(selected, key=lambda x: x.relevance_score, reverse=True)
            proposition, rationale = self.proposition_builder.build(node, question, selected)

            submitted.append(
                B3SubmittedBinding(
                    target_address=node.address,
                    target_text=node.text,
                    semantic_class=node.semantic_class,
                    satisfaction_question=question,
                    eligible_planes=eligible_planes,
                    considered_atom_ids=[a.atom_id for a in eligible_atoms],
                    selected_atoms=[x.atom for x in selected],
                    proposed_proposition=proposition,
                    source_span_ids=list(node.source_span_ids),
                    binding_rationale=rationale,
                )
            )

        return submitted

    @staticmethod
    def _derive_question(node: B2TargetNode) -> str:
        if node.semantic_class == SemanticClass.HARD_GATE:
            return f"What candidate evidence specifically establishes mandatory compliance with: {node.text}?"
        if node.semantic_class == SemanticClass.CONTEXTUAL_SOFT:
            return f"What candidate evidence specifically supports the contextual/preferred condition: {node.text}?"
        return f"What candidate evidence specifically demonstrates responsibility or capability in: {node.text}?"


class StageB4_TheGate:
    """Specific-truth audit and correction boundary."""

    def __init__(self, auditor: TruthAuditor):
        self.auditor = auditor

    def execute(self, bindings: List[B3SubmittedBinding]) -> List[B4AuditedRecord]:
        audited: List[B4AuditedRecord] = []
        for binding in bindings:
            result = self.auditor.audit(binding)
            self._validate_result(binding, result)

            selected_by_id = {a.atom_id: a for a in binding.selected_atoms}
            bound_atoms = [selected_by_id[x] for x in result.bound_atom_ids]
            excluded_atoms = [selected_by_id[x] for x in result.excluded_atom_ids]

            audited.append(
                B4AuditedRecord(
                    target_address=binding.target_address,
                    target_text=binding.target_text,
                    semantic_class=binding.semantic_class,
                    satisfaction_question=binding.satisfaction_question,
                    eligible_planes=list(binding.eligible_planes),
                    submitted_proposition=binding.proposed_proposition,
                    final_proposition=result.final_proposition,
                    gate_disposition=result.disposition,
                    gate_defect_reason=result.defect_reason,
                    resolution_state=result.resolution_state,
                    bound_atoms=bound_atoms,
                    excluded_atoms=excluded_atoms,
                    target_span_ids=list(binding.source_span_ids),
                )
            )
        return audited

    @staticmethod
    def _validate_result(binding: B3SubmittedBinding, result) -> None:
        selected_ids = {a.atom_id for a in binding.selected_atoms}
        unknown_bound = set(result.bound_atom_ids) - selected_ids
        unknown_excluded = set(result.excluded_atom_ids) - selected_ids
        if unknown_bound or unknown_excluded:
            raise ValueError(
                f"B4 auditor referenced atoms not selected by B3: "
                f"bound={sorted(unknown_bound)} excluded={sorted(unknown_excluded)}"
            )

        if result.disposition == GateDisposition.PASS and result.resolution_state != ResolutionState.FULLY_SUPPORTED:
            raise ValueError("PASS must resolve as FULLY_SUPPORTED.")

        if binding.semantic_class == SemanticClass.HARD_GATE:
            if result.resolution_state == ResolutionState.QUALIFIED_RESTRICTED_SCOPE:
                raise ValueError(
                    "Hard-gate violation: a mandatory target node cannot be converted into satisfaction "
                    "by narrowing it to a qualified scope. Return/research or preserve unresolved/contradicted state."
                )

        if result.disposition != GateDisposition.PASS and not result.defect_reason:
            raise ValueError("Non-PASS B4 results require a specific defect reason.")


class StageB5_EntryBoundary:
    """Validates and packages B4 output, then STOP.

    No semantic-core synthesis, prism reasoning, advocacy, scoring, or Boundary C compilation occurs here.
    """

    def execute(self, tree: B2TargetTree, audited_records: List[B4AuditedRecord]) -> B5EntryPacket:
        by_addr = {r.target_address: r for r in audited_records}
        missing = set(tree.nodes) - set(by_addr)
        extra = set(by_addr) - set(tree.nodes)
        if missing or extra:
            raise ValueError(
                f"B5 entry ledger mismatch: missing={sorted(missing)} extra={sorted(extra)}"
            )

        return B5EntryPacket(
            target_id=tree.target_id,
            identification=tree.identification,
            routing=tree.routing,
            target_tree=tree,
            audited_records=by_addr,
            fully_supported_nodes=sorted(
                a for a, r in by_addr.items() if r.resolution_state == ResolutionState.FULLY_SUPPORTED
            ),
            qualified_nodes=sorted(
                a for a, r in by_addr.items() if r.resolution_state == ResolutionState.QUALIFIED_RESTRICTED_SCOPE
            ),
            unresolved_nodes=sorted(
                a for a, r in by_addr.items() if r.resolution_state == ResolutionState.UNRESOLVED_ATOMIC_LEVEL
            ),
            contradicted_nodes=sorted(
                a for a, r in by_addr.items() if r.resolution_state == ResolutionState.CONTRADICTED
            ),
        )
