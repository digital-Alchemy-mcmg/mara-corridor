from __future__ import annotations

from typing import Dict, List

from .contracts import B5EntryPacket, CandidateEvidenceAtom, ScoutObservationPacket, SDNAPlaneId
from .interfaces import EvidenceSelector, PlaneRouter, PropositionBuilder, TargetDecomposer, TruthAuditor
from .stages import (
    StageB_Handoff,
    StageB1_Decouple,
    StageB2_CreateTree,
    StageB3_Bind,
    StageB4_TheGate,
    StageB5_EntryBoundary,
)


class MaraBToB5BoundaryOrchestrator:
    """B handoff → B1 → B2 → B3 → B4 → STOP at B5 entry."""

    def __init__(
        self,
        *,
        decomposer: TargetDecomposer,
        plane_router: PlaneRouter,
        evidence_selector: EvidenceSelector,
        proposition_builder: PropositionBuilder,
        truth_auditor: TruthAuditor,
    ):
        self.b = StageB_Handoff()
        self.b1 = StageB1_Decouple(decomposer)
        self.b2 = StageB2_CreateTree()
        self.b3 = StageB3_Bind(plane_router, evidence_selector, proposition_builder)
        self.b4 = StageB4_TheGate(truth_auditor)
        self.b5_boundary = StageB5_EntryBoundary()

    def run(
        self,
        scout_packet: ScoutObservationPacket,
        candidate_vault: Dict[SDNAPlaneId, List[CandidateEvidenceAtom]],
        *,
        diagnostic_mode: bool = True,
    ) -> B5EntryPacket:
        packet = self.b.execute(scout_packet)
        decomposition = self.b1.execute(packet, diagnostic_mode=diagnostic_mode)
        tree = self.b2.execute(decomposition)
        bindings = self.b3.execute(tree, candidate_vault)
        audited = self.b4.execute(bindings)
        return self.b5_boundary.execute(tree, audited)
