from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


class SemanticClass(str, Enum):
    HARD_GATE = "HARD_GATE"                  # '*' explicit candidate admission prerequisite
    CONTEXTUAL_SOFT = "CONTEXTUAL_SOFT"      # '≈' preferred/contextual/qualitative condition
    ROLE_RESPONSIBILITY = "ROLE_RESPONSIBILITY"  # unmarked operational duty/responsibility


class MalformState(str, Enum):
    VALID = "VALID"
    MALFORMED_ORIGIN_MISSING = "MALFORMED — ORIGIN MISSING"
    MALFORMED_DESTINATION_MISSING = "MALFORMED — DESTINATION MISSING"
    MALFORMED_UNROUTABLE = "MALFORMED — UNROUTABLE JOB OBJECT"


class SDNAPlaneId(str, Enum):
    PLANE_01_IDENTITY = "PLANE_01_IDENTITY"
    PLANE_02_WORK_HISTORY = "PLANE_02_WORK_HISTORY"
    PLANE_03_EDUCATION_TECH = "PLANE_03_EDUCATION_TECH"
    PLANE_04_CREATIVE_PROJECTS = "PLANE_04_CREATIVE_PROJECTS"
    PLANE_05_COGNITIVE_PROFILE = "PLANE_05_COGNITIVE_PROFILE"
    PLANE_06_TESTIMONY_REFERENCES = "PLANE_06_TESTIMONY_REFERENCES"


class GateDisposition(str, Enum):
    PASS = "PASS"
    RETURN_CONDITIONAL = "RETURN — CONDITIONAL"
    RETURN_FAIL = "RETURN — FAIL"


class ResolutionState(str, Enum):
    FULLY_SUPPORTED = "PASS / FULLY SUPPORTED"
    QUALIFIED_RESTRICTED_SCOPE = "QUALIFIED / BOUND AT RESTRICTED SCOPE"
    UNRESOLVED_ATOMIC_LEVEL = "UNRESOLVED AT ATOMIC LEVEL"
    CONTRADICTED = "CONTRADICTED"


@dataclass(frozen=True)
class SourceSpan:
    span_id: str
    text: str


@dataclass(frozen=True)
class ScoutObservationPacket:
    """Schema-validatable handoff object from Scout into MARA.

    B validates shape only. B1 is responsible for semantic decomposition and malform state.
    """
    packet_id: str
    raw_posting: str
    source_uri: Optional[str] = None
    source_label: Optional[str] = None
    observed_metadata: Dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class TargetIdentification:
    organization: Optional[str] = None
    job_title: Optional[str] = None
    contextual_segment: Optional[str] = None
    location: Optional[str] = None
    employment_type: Optional[str] = None
    compensation: Optional[str] = None
    schedule: Optional[str] = None


@dataclass(frozen=True)
class ApplicationRouting:
    origin: Optional[str] = None
    destination: Optional[str] = None
    endpoint_url: Optional[str] = None
    application_method: Optional[str] = None
    contact: Optional[str] = None
    required_materials: List[str] = field(default_factory=list)
    subject_line: Optional[str] = None
    special_instructions: List[str] = field(default_factory=list)
    malform_state: MalformState = MalformState.VALID
    diagnostic_authorized: bool = False


@dataclass(frozen=True)
class B1RequirementAtom:
    """Atomic target-side unit produced by B1.

    `branch_path` is target-derived and intentionally free-form; B2 converts it into
    deterministic lowercase/alphanumeric addresses without imposing a fixed domain taxonomy.
    """
    requirement_id: str
    text: str
    semantic_class: SemanticClass
    source_span_ids: List[str]
    branch_path: List[str]
    qualifiers: List[str] = field(default_factory=list)


@dataclass(frozen=True)
class B1Decomposition:
    target_id: str
    identification: TargetIdentification
    routing: ApplicationRouting
    source_spans: List[SourceSpan]
    requirements: List[B1RequirementAtom]


@dataclass(frozen=True)
class B2TargetNode:
    address: str
    text: str
    semantic_class: SemanticClass
    source_span_ids: List[str]
    qualifiers: List[str] = field(default_factory=list)
    parent_address: Optional[str] = None
    branch_path: List[str] = field(default_factory=list)


@dataclass
class B2TargetTree:
    target_id: str
    identification: TargetIdentification
    routing: ApplicationRouting
    nodes: Dict[str, B2TargetNode] = field(default_factory=dict)
    frozen: bool = False

    def add_node(self, node: B2TargetNode) -> None:
        if self.frozen:
            raise RuntimeError("Cannot modify frozen Target Tree.")
        if node.address in self.nodes:
            raise ValueError(f"Duplicate target address: {node.address}")
        self.nodes[node.address] = node

    def freeze(self) -> None:
        self.frozen = True


@dataclass(frozen=True)
class CandidateEvidenceAtom:
    atom_id: str
    source_plane: SDNAPlaneId
    documentary_source: str
    verified_text: str
    metadata: Dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class EvidenceCandidate:
    atom: CandidateEvidenceAtom
    relevance_score: float
    rationale: str


@dataclass(frozen=True)
class B3SubmittedBinding:
    target_address: str
    target_text: str
    semantic_class: SemanticClass
    satisfaction_question: str
    eligible_planes: List[SDNAPlaneId]
    considered_atom_ids: List[str]
    selected_atoms: List[CandidateEvidenceAtom]
    proposed_proposition: str
    source_span_ids: List[str]
    binding_rationale: str


@dataclass(frozen=True)
class GateAuditResult:
    disposition: GateDisposition
    resolution_state: ResolutionState
    final_proposition: str
    defect_reason: Optional[str] = None
    bound_atom_ids: List[str] = field(default_factory=list)
    excluded_atom_ids: List[str] = field(default_factory=list)


@dataclass(frozen=True)
class B4AuditedRecord:
    target_address: str
    target_text: str
    semantic_class: SemanticClass
    satisfaction_question: str
    eligible_planes: List[SDNAPlaneId]
    submitted_proposition: str
    final_proposition: str
    gate_disposition: GateDisposition
    gate_defect_reason: Optional[str]
    resolution_state: ResolutionState
    bound_atoms: List[CandidateEvidenceAtom]
    excluded_atoms: List[CandidateEvidenceAtom]
    target_span_ids: List[str]


@dataclass(frozen=True)
class B5EntryPacket:
    """Termination object for this package.

    This package intentionally stops at B5 entry. It does not perform B5 Semantic Core
    Reasoning and does not compile Boundary C payloads.
    """
    target_id: str
    identification: TargetIdentification
    routing: ApplicationRouting
    target_tree: B2TargetTree
    audited_records: Dict[str, B4AuditedRecord]
    fully_supported_nodes: List[str]
    qualified_nodes: List[str]
    unresolved_nodes: List[str]
    contradicted_nodes: List[str]
    status: str = "READY_FOR_B5_SEMANTIC_CORE"
