from __future__ import annotations

from typing import List, Protocol

from .contracts import (
    B1Decomposition,
    B2TargetNode,
    CandidateEvidenceAtom,
    EvidenceCandidate,
    GateAuditResult,
    ScoutObservationPacket,
    SDNAPlaneId,
    B3SubmittedBinding,
)


class TargetDecomposer(Protocol):
    """Semantic adapter used by B1.

    Implementation may be LLM-backed or deterministic, but it must operate candidate-blind.
    """

    def decompose(self, packet: ScoutObservationPacket, diagnostic_mode: bool) -> B1Decomposition:
        ...


class PlaneRouter(Protocol):
    """Derives eligible SDNA planes from the target node, not from candidate-side scores."""

    def eligible_planes(self, node: B2TargetNode) -> List[SDNAPlaneId]:
        ...


class EvidenceSelector(Protocol):
    """Selects responsive atoms inside the target-derived eligible plane set."""

    def select(
        self,
        node: B2TargetNode,
        satisfaction_question: str,
        eligible_atoms: List[CandidateEvidenceAtom],
    ) -> List[EvidenceCandidate]:
        ...


class PropositionBuilder(Protocol):
    """Forms the proposition B3 submits to B4 from selected evidence only."""

    def build(
        self,
        node: B2TargetNode,
        satisfaction_question: str,
        selected: List[EvidenceCandidate],
    ) -> tuple[str, str]:
        """Returns (proposed_proposition, binding_rationale)."""
        ...


class TruthAuditor(Protocol):
    """B4 specific-truth evaluator.

    Must not use title inference, occupational convention, or necessity arguments as proof.
    """

    def audit(self, binding: B3SubmittedBinding) -> GateAuditResult:
        ...
