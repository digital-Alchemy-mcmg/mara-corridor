# Spatial DNA — MARA B through B5 Entry

Corrected Python architecture package for:

`B handoff → B1 Decouple → B2 Create Tree → B3 Bind → B4 The Gate → B5 entry stop`

This package is intentionally **not** a complete application. It provides the stage contracts, invariants, orchestration, and semantic adapter interfaces needed for Codex to wire the real reasoning implementation without target-specific mock data.

## Run tests

```bash
python -m pytest -q
```

## Main entry

```python
from spatial_dna.orchestrator import MaraBToB5BoundaryOrchestrator
```

Construct it with implementations of the five semantic interfaces defined in `spatial_dna/interfaces.py`.

## Output

`B5EntryPacket(status="READY_FOR_B5_SEMANTIC_CORE")`

No B5 reasoning or Boundary C compilation occurs.
